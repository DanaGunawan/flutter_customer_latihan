import 'dart:convert';

List<ModelCustomers> modelCustomersFromJson(String str) => List<ModelCustomers>.from(json.decode(str).map((x) => ModelCustomers.fromJson(x)));

class ModelCustomers {
  String id;
  String name;
  String email;
  String usertype;
  String phone;
  String address;
  String password;


  ModelCustomers({
    required this.id,
    required this.name,
    required this.email,
    required this.usertype,
    required this.phone,
    required this.address,
    required this.password,

  });

  factory ModelCustomers.fromJson(Map<String, dynamic> json) => ModelCustomers(
    id: json["id"],
    name: json["name"],
    email: json["email"],
    usertype: json["usertype"],
    phone: json["phone"],
    address: json["address"],
    password: json["password"],

  );
}
