import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'insertuser.dart';

class CustomerCardScreen extends StatefulWidget {
  @override
  _CustomerCardScreenState createState() => _CustomerCardScreenState();
}

class _CustomerCardScreenState extends State<CustomerCardScreen> {
  late Future<List<ModelCustomers>> futureCustomers;

  Future<List<ModelCustomers>> fetchCustomers() async {
    try {
      final response = await http.get(Uri.parse('http://10.5.4.49/fluttersql/find.php'));

      if (response.statusCode == 200) {
        return modelCustomersFromJson(response.body);
      } else {
        throw Exception('Failed to load customers. Status code: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Failed to load customers. Error: $e');
    }
  }

  @override
  void initState() {
    super.initState();
    futureCustomers = fetchCustomers();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Customer Cards'),
      ),
      body: FutureBuilder<List<ModelCustomers>>(
        future: futureCustomers,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text('No data found'));
          } else {
            return ListView.builder(
              itemCount: snapshot.data!.length,
              itemBuilder: (context, index) {
                return CustomerCard(customer: snapshot.data![index]);
              },
            );
          }
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => InsertDataPage()),
          );
        },
        child: Icon(Icons.add),
      ),
    );
  }
}

class CustomerCard extends StatelessWidget {
  final ModelCustomers customer;

  const CustomerCard({Key? key, required this.customer}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.all(10),
      child: Padding(
        padding: EdgeInsets.all(15),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              customer.name,
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 10),
            Text('Email: ${customer.email}'),
            Text('Phone: ${customer.phone}'),
            Text('Address: ${customer.address}'),
            Text('User Type: ${customer.usertype}'),
          ],
        ),
      ),
    );
  }
}

List<ModelCustomers> modelCustomersFromJson(String str) => List<ModelCustomers>.from(json.decode(str).map((x) => ModelCustomers.fromJson(x)));

class ModelCustomers {
  String id;
  String name;
  String email;
  String usertype;
  String phone;
  String address;

  ModelCustomers({
    required this.id,
    required this.name,
    required this.email,
    required this.usertype,
    required this.phone,
    required this.address,
  });

  factory ModelCustomers.fromJson(Map<String, dynamic> json) => ModelCustomers(
    id: json["id"],
    name: json["name"],
    email: json["email"],
    usertype: json["usertype"],
    phone: json["phone"],
    address: json["address"],
  );
}
